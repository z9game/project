package kosmo.team.project.dto;

public class TournamentDTO {
	
	private String subject;
	private String region;
	private String content;
	private String regist_start;
	private String regist_end;
	
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegist_start() {
		return regist_start;
	}
	public void setRegist_start(String regist_start) {
		this.regist_start = regist_start;
	}
	public String getRegist_end() {
		return regist_end;
	}
	public void setRegist_end(String regist_end) {
		this.regist_end = regist_end;
	}

}
