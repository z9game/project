package kosmo.team.project.dto;

public class MemberDTO {
	private int m_no;
	private String name;
	private String mid;
	private String password;
	private String nickname;
	private String email;
	private String birthday;
	private String phone;
	private String gender;
	private int sido_id;
	private int sigungu_id;
	private String detail_address;
	private String reg_date;
	
	
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getSido_id() {
		return sido_id;
	}
	public void setSido_id(int sido_id) {
		this.sido_id = sido_id;
	}
	public int getSigungu_id() {
		return sigungu_id;
	}
	public void setSigungu_id(int sigungu_id) {
		this.sigungu_id = sigungu_id;
	}
	public String getDetail_address() {
		return detail_address;
	}
	public void setDetail_address(String detail_address) {
		this.detail_address = detail_address;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	
	
	
	
	

	
	
}
